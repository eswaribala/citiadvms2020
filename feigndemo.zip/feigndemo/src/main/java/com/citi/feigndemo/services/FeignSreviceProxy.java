package com.citi.feigndemo.services;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.FeignClientProperties.FeignClientConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "CUSTOMER-SERVICE",configuration = FeignClientConfiguration.class )
public interface FeignSreviceProxy {

	@GetMapping("/customers")
	public ResponseEntity<String> getCustomers();
}
