package com.citi.hystrixdemo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class HystrixServiceProxy {
    @Autowired
	private RestTemplate restTemplate;
    @HystrixCommand(fallbackMethod = "handleFailure",commandProperties = {
    	       @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "3000"),
    	       @HystrixProperty(name = "circuitBreaker.errorThresholdPercentage", value="60"),
    	       @HystrixProperty(name="execution.isolation.strategy", value="SEMAPHORE")
    	    }
)
	public String handleRequest()
	{
		//inter service communication one to one
		return restTemplate.exchange("http://localhost:8765/api/customer/customers", 
    			HttpMethod.GET,null, 
				new ParameterizedTypeReference<String>() {
        }).getBody();
	}
	
	public String handleFailure()
	{
		//inter service communication one to one
		return restTemplate.exchange("http://localhost:7080/customers", 
    			HttpMethod.GET,null, 
				new ParameterizedTypeReference<String>() {
        }).getBody();
	}
	
	
	
	
	
}
