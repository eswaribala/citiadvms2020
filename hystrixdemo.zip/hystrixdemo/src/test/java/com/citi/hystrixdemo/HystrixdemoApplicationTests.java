package com.citi.hystrixdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystrixdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
