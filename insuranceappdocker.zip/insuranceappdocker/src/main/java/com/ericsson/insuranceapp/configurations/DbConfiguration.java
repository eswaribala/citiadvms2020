package com.ericsson.insuranceapp.configurations;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;


@Configuration

public class DbConfiguration {
	 private static final Logger logger = LoggerFactory.getLogger(DbConfiguration.class);
	//citi-production.properties
	 @Value("${db_url}")
	private String url;
	@Value("${db_driver}")
	private String driverClassName;
	@Value("${db_username}")
	private String userName;
	@Value("${db_password}")
	private String password;
	//config-server-client.properties
	@Value("${serviceUrl}")
	private String serviceUrl;

	
	@Bean
	public DataSource prodDataSource()
	{
		
		DataSourceBuilder builder= DataSourceBuilder.create();
		builder.url(url);
		builder.username(userName);
		builder.password(password);
		builder.driverClassName(driverClassName);
		System.out.println("Production.....");
	    System.out.println(serviceUrl);



		return builder.build();	
	}
	

}
