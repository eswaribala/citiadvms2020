package com.ericsson.insuranceapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceappApplicationTests {

	@Test
	void contextLoads() {
	}

}
