package com.citi.ribbonlb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RibbonlbApplicationTests {

	@Test
	void contextLoads() {
	}

}
