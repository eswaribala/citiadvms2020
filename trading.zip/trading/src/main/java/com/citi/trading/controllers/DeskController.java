package com.citi.trading.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.trading.models.Bank;
import com.citi.trading.models.Desk;
import com.citi.trading.services.DeskService;

@RestController
public class DeskController {

	 @Autowired
		private DeskService deskService;
	     
	   //adding the Desk
	 	@PostMapping("/desks")
	 	public @ResponseBody Desk addDesk(@RequestBody Desk Desk)
	 	{
	 		return this.deskService.addDesk(Desk);
	 	}

	 	//retrieve all Desks
	 	@GetMapping("/desks")
	 	public List<Desk> findAllDesks()
	 	{
	 		return this.deskService.getAllDesks();
	 		
	 	}
	 	
	 	//retrieve bank by id
 	 	@GetMapping("/desks/{deskId}")
 	 	public Desk findDeskById(@PathVariable("deskId") long deskId)
 	 	{
 	 		return this.deskService.getDeskById(deskId);
 	 	}
}
