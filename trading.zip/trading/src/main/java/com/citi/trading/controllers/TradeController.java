package com.citi.trading.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.trading.models.Trade;
import com.citi.trading.models.Trader;
import com.citi.trading.services.TradeService;

@RestController
public class TradeController {
    @Autowired
	private TradeService tradeService;
	@PostMapping("/trades/{bankId}/{deskId}/{fromCustomerId}/{toCustomerId}/{traderId}")
	public ResponseEntity<String> addTrade(@PathVariable("bankId") long bankId,
			@PathVariable("deskId") long deskId, @PathVariable("traderId") long traderId,
			@PathVariable("fromCustomerId") long fromCustomerId,
			@PathVariable("toCustomerId") long toCustomerId,
		    @RequestBody Trade trade)
	{
		
		boolean status=this.tradeService.addTrade(fromCustomerId, toCustomerId, traderId, bankId, deskId, trade);
		if(status)
		  return ResponseEntity.ok("Trade Created");
		else
			return  ResponseEntity.ok("Trading not possible");
		
	}
	
	
}
