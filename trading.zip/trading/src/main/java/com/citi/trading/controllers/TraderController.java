package com.citi.trading.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.trading.models.Trader;
import com.citi.trading.services.TraderService;

@RestController
public class TraderController {

	 @Autowired
		private TraderService traderService;
	     
	   //adding the Trader
	 	@PostMapping("/Traders")
	 	public @ResponseBody Trader addTrader(@RequestBody Trader Trader)
	 	{
	 		return this.traderService.addTrader(Trader);
	 	}

	 	//retrieve all Traders
	 	@GetMapping("/Traders")
	 	public List<Trader> findAllTraders()
	 	{
	 		return this.traderService.getAllTraders();
	 		
	 	}
}
