package com.citi.trading.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="Citi_Bank")
@Data
public class Bank {
    @Id
	@Column(name="Bank_Id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long bankId;
    @Column(name="Bank_Name",nullable = false,length = 50)
    private String bankName;
    
}
