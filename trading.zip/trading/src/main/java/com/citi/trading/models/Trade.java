package com.citi.trading.models;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name="Trade_Booking")
@Data
public class Trade {
	@Id
	@Column(name="Trade_Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
    private long tradeId;
	@Column(name="FromCustomer_Id", nullable=false, length=50)
	private long fromCustomerId;
	@Column(name="ToCustomer_Id", nullable=false, length=50)
	private long toCustomerId;
    private LocalDate date;
    @Column(name="Price")
    private long price;
    @Column(name="Qty")
    private long qty;
    @ManyToOne(cascade = CascadeType.MERGE,fetch = FetchType.LAZY)
    @JoinColumn(name = "Trader_Id")
	private Trader trader;
    @ManyToOne(cascade = CascadeType.MERGE,fetch = FetchType.LAZY)
    @JoinColumn(name = "Bank_Id")
	private Bank bank;
    @ManyToOne(cascade = CascadeType.MERGE,fetch = FetchType.LAZY)
    @JoinColumn(name = "Desk_Id")
	private Desk desk;

}
