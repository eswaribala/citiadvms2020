package com.citi.trading.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="Citi_Trader")
@Data
public class Trader {
	@Id
	@Column(name="Trader_Id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)	
    private long traderId;
	@Column(name="Trader_Name",nullable = false,length = 50)
	private String traderName;
   

}
