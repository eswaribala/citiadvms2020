package com.citi.trading.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.trading.models.Bank;

public interface BankRepository extends JpaRepository<Bank,Long>{

}
