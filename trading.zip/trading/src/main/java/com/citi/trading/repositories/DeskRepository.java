package com.citi.trading.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.trading.models.Desk;


public interface DeskRepository extends JpaRepository<Desk,Long>{

}
