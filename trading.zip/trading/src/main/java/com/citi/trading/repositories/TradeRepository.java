package com.citi.trading.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.trading.models.Trade;


public interface TradeRepository  extends JpaRepository<Trade,Long>{

}
