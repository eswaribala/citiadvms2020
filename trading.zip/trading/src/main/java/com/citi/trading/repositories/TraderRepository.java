package com.citi.trading.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.trading.models.Trader;

public interface TraderRepository extends JpaRepository<Trader,Long>{

}
