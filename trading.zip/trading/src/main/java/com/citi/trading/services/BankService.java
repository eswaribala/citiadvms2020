package com.citi.trading.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.trading.models.Bank;
import com.citi.trading.repositories.BankRepository;

@Service
public class BankService {
	@Autowired
	private BankRepository bankRepo;
	public Bank addBank(Bank bank)
	{
		return this.bankRepo.save(bank);
	}

	public List<Bank> getAllBanks()
	{
		return this.bankRepo.findAll();
	}
	
	public Bank getBankById(long bankId)
	{
		return this.bankRepo.findById(bankId).orElse(null);
	}
	
	
}
