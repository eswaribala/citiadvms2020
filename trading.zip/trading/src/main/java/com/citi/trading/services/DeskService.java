package com.citi.trading.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.trading.models.Bank;
import com.citi.trading.models.Desk;

import com.citi.trading.repositories.DeskRepository;
@Service
public class DeskService {

	@Autowired
	private DeskRepository deskRepo;
	public Desk addDesk(Desk desk)
	{
		return this.deskRepo.save(desk);
	}

	public List<Desk> getAllDesks()
	{
		return this.deskRepo.findAll();
	}
	
	
	public Desk getDeskById(long deskId)
	{
		return this.deskRepo.findById(deskId).orElse(null);
	}
	
}
