package com.citi.trading.services;

public class TradeService {

}
