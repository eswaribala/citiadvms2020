package com.citi.trading.services;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.citi.trading.models.Bank;
import com.citi.trading.models.Desk;
import com.citi.trading.models.Trade;
import com.citi.trading.models.Trader;
import com.citi.trading.repositories.TradeRepository;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.github.wnameless.json.unflattener.JsonUnflattener;

import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;

@Service
public class TradeService {
	@Value("${bankServiceUrl}")
	private String bankServiceUrl;
	@Value("${deskServiceUrl}")
	private String deskServiceUrl;
	@Value("${customerServiceUrl}")
	private String customerServiceUrl;
	@Autowired
	private TraderService traderService;
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private TradeRepository tradeRepo;
	
	public boolean addTrade(long fromCustomerId,long toCustomerId,long traderId, long bankId, long deskId,Trade trade)
	{
		boolean status=false;
        //verify bank     	   
		ResponseEntity<Bank> bank = restTemplate.exchange(bankServiceUrl+"/"+bankId,HttpMethod.GET,null,Bank.class);
		//verify desk
		ResponseEntity<Desk> desk = restTemplate.exchange(deskServiceUrl+"/"+deskId,HttpMethod.GET,null,Desk.class);
		//verify from customer
		ResponseEntity<String> fromCustomerData = restTemplate.exchange(customerServiceUrl+"/filters/"+fromCustomerId+"?fields=customerId",
				HttpMethod.GET,null,String.class);
		
		long fromCustomerValue=this.parseString(fromCustomerData.getBody());
		
		//verify to customer
		ResponseEntity<String> toCustomerData = restTemplate.exchange(customerServiceUrl+"/filters/"+toCustomerId+"?fields=customerId",
				HttpMethod.GET,null,String.class);
		
		long toCustomerValue=this.parseString(toCustomerData.getBody());
		//verify Trader
		Trader trader = this.traderService.getTraderById(traderId);
		if(bank!=null)
		{
			trade.setBank(bank.getBody());
		    if(desk!=null)
		    {
		    	trade.setDesk(desk.getBody());
		    	if(trader!=null)
		    	{
		    		trade.setTrader(trader);
		    	    if((fromCustomerValue>0) &&(toCustomerValue>0))
		    	    {
		    	    	trade.setFromCustomerId(fromCustomerValue);
		    	    	trade.setToCustomerId(toCustomerValue);
		    	    	tradeRepo.save(trade);
		    	    	status=true;
		    	    }

		    	} 
		    	
		    }
		}
		
		return status;
		
		
	}
	
	
	
	
	private long parseString(String response)
	{
		JSONParser parser = new JSONParser(); 
		long customerId=0;
	  	try {
	  		 
			// Put above JSON content to crunchify.txt file and change path location
			Object obj = parser.parse(response);
			JSONObject jsonObject = (JSONObject) obj;
 
			// JsonFlattener: A Java utility used to FLATTEN nested JSON objects
			String flattenedJson = JsonFlattener.flatten(jsonObject.toString());
			
			System.out.println(flattenedJson);
			//log("\n=====Simple Flatten===== \n" + flattenedJson);
 
			Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(jsonObject.toString());
		 
			customerId=Long.parseLong(flattenedJsonMap.get("customerId").toString());    
			//log("\n=====Flatten As Map=====\n" + flattenedJson);
			// We are using Java8 forEach loop. More info: https://crunchify.com/?p=8047
			//flattenedJsonMap.forEach((k, v) -> log(k + " : " + v));
 
			// Unflatten it back to original JSON
			String nestedJson = JsonUnflattener.unflatten(flattenedJson);
			System.out.println("\n=====Unflatten it back to original JSON===== \n" + nestedJson);
		} catch (Exception e) {
			e.printStackTrace();
		}
	 return customerId;

	}

	
}
