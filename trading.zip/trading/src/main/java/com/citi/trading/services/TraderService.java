package com.citi.trading.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.trading.models.Trader;

import com.citi.trading.repositories.TraderRepository;
@Service
public class TraderService {

	@Autowired
	private TraderRepository traderRepo;
	public Trader addTrader(Trader trader)
	{
		return this.traderRepo.save(trader);
	}

	public List<Trader> getAllTraders()
	{
		return this.traderRepo.findAll();
	}
}
